import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';
import Dashboard from './components/Dashboard';
import KidsDashboard from './components/KidsDashboard';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import AssumptionTracker from './components/AssumptionTracker';
import Reports from './components/Reports';
import Settings from './components/Settings';
import NotificationContainer from './components/NotificationContainer';
import { ReactorDataProvider } from './context/ReactorDataContext';
import { ThemeProvider } from './context/ThemeContext';
import { AppModeProvider, useAppMode } from './context/AppModeContext';
import { NotificationProvider } from './context/NotificationContext';

const AppContent: React.FC = () => {
  const { appMode } = useAppMode();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Close sidebar on small screens by default
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };
    
    // Initial check
    handleResize();
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex flex-col h-screen font-['Inter',sans-serif]">
      <Navbar toggleSidebar={toggleSidebar} />
      <div className="flex flex-1 overflow-hidden">
        <div className={`md:static fixed inset-y-0 left-0 z-50 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0`}>
          <Sidebar closeSidebar={() => setSidebarOpen(false)} />
        </div>
        {/* Overlay to close sidebar on mobile */}
        {sidebarOpen && (
          <div 
            className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={() => setSidebarOpen(false)}
          ></div>
        )}
        <main className="flex-1 overflow-auto p-4 md:p-6 transition-all duration-300">
          <Routes>
            <Route path="/" element={appMode === 'expert' ? <Dashboard /> : <KidsDashboard />} />
            <Route path="/assumptions" element={<AssumptionTracker />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
          <footer className="mt-8 text-xs text-center p-2 text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700">
            <p className="mb-2">This is a simulation for educational purposes only.</p>
            <div className="flex flex-wrap justify-center gap-2 md:gap-4">
              <span>Presented by <a href="https://x.com/davidtphung" className="hover:underline text-blue-600 dark:text-blue-400" target="_blank" rel="noopener noreferrer">David T Phung</a></span>
              <span>⚛</span>
              <a href="https://makenuclearenergygreatagain.com" className="hover:underline text-blue-600 dark:text-blue-400" target="_blank" rel="noopener noreferrer">makenuclearenergygreatagain.com</a>
            </div>
            <div className="flex flex-wrap justify-center gap-2 md:gap-4 mt-2">
              <span>Powered by:</span>
              <a href="https://davidtphung.com" className="hover:underline text-blue-600 dark:text-blue-400" target="_blank" rel="noopener noreferrer">NLT143</a>
              <span>|</span>
              <a href="https://warpcast.com/davidtphung" className="hover:underline text-blue-600 dark:text-blue-400" target="_blank" rel="noopener noreferrer">Warpcast</a>
              <span>|</span>
              <a href="https://www.youtube.com/playlist?list=PLqchICbseuRpn8PqBDDXwnpAp5MI-9-zN" className="hover:underline text-blue-600 dark:text-blue-400" target="_blank" rel="noopener noreferrer">YouTube Podcast</a>
            </div>
          </footer>
        </main>
      </div>
      <NotificationContainer />
    </div>
  );
};

const App: React.FC = () => {
  // Load Google font
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    return () => {
      document.head.removeChild(link);
    };
  }, []);

  return (
    <ThemeProvider>
      <AppModeProvider>
        <NotificationProvider>
          <ReactorDataProvider>
            <Router>
              <AppContent />
            </Router>
          </ReactorDataProvider>
        </NotificationProvider>
      </AppModeProvider>
    </ThemeProvider>
  );
};

export default App;
