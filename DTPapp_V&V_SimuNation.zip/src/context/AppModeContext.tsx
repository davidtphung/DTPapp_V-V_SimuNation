import React, { createContext, useContext, useState, useEffect } from 'react';

type AppMode = 'expert' | 'kids';

type AppModeContextType = {
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  toggleAppMode: () => void;
};

const AppModeContext = createContext<AppModeContextType | undefined>(undefined);

export const AppModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [appMode, setAppMode] = useState<AppMode>(() => {
    const savedMode = localStorage.getItem('appMode');
    return (savedMode as AppMode) || 'expert';
  });

  useEffect(() => {
    localStorage.setItem('appMode', appMode);
  }, [appMode]);

  const toggleAppMode = () => {
    setAppMode(prevMode => prevMode === 'expert' ? 'kids' : 'expert');
  };

  return (
    <AppModeContext.Provider value={{ appMode, setAppMode, toggleAppMode }}>
      {children}
    </AppModeContext.Provider>
  );
};

export const useAppMode = (): AppModeContextType => {
  const context = useContext(AppModeContext);
  if (context === undefined) {
    throw new Error('useAppMode must be used within an AppModeProvider');
  }
  return context;
};
