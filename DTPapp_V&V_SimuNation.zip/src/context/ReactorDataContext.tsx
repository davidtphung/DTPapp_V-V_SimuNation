import React, { createContext, useContext, useState, useEffect } from 'react';

export interface ReactorData {
  timestamp: number;
  coreTemperature: number;
  neutronFlux: number;
  coolantFlow: number;
  controlRodPosition: number;
  powerOutput: number;
  containmentPressure: number;
  safetyStatus: 'normal' | 'warning' | 'critical';
  regulatoryAlerts: Array<{
    id: string;
    message: string;
    severity: 'info' | 'warning' | 'critical';
    source: string;
    timestamp: number;
  }>;
}

interface ReactorContextType {
  reactorData: ReactorData;
  updateControlRods: (position: number) => void;
  systemMode: 'normal' | 'maintenance' | 'shutdown';
  setSystemMode: (mode: 'normal' | 'maintenance' | 'shutdown') => void;
}

const ReactorDataContext = createContext<ReactorContextType | undefined>(undefined);

// Simulate realistic reactor behavior
const simulateReactorData = (
  previousData: ReactorData, 
  controlRodPosition: number,
  mode: 'normal' | 'maintenance' | 'shutdown'
): ReactorData => {
  // Base values depend on mode
  let baseCoreTemp = mode === 'shutdown' ? 100 : mode === 'maintenance' ? 200 : 350;
  let baseNeutronFlux = mode === 'shutdown' ? 5 : mode === 'maintenance' ? 20 : 75;
  let basePowerOutput = mode === 'shutdown' ? 0 : mode === 'maintenance' ? 15 : 95;
  
  // Control rod effect (0 = fully inserted, 100 = fully withdrawn)
  const rodFactor = controlRodPosition / 100;
  
  // Calculate new values with some randomness for realistic fluctuation
  const coreTemperature = baseCoreTemp + (rodFactor * 250) + (Math.random() * 10 - 5);
  const neutronFlux = baseNeutronFlux + (rodFactor * 40) + (Math.random() * 4 - 2);
  const powerOutput = Math.max(0, basePowerOutput + (rodFactor * 30) - (Math.random() * 5));
  
  // Coolant flow increases with temperature
  const coolantFlow = 65 + (coreTemperature / 600 * 35) + (Math.random() * 3 - 1.5);
  
  // Containment pressure relates to temperature but has its own behavior
  const containmentPressure = 20 + (coreTemperature / 800 * 10) + (Math.random() * 2 - 1);
  
  // Determine safety status
  let safetyStatus: 'normal' | 'warning' | 'critical' = 'normal';
  if (coreTemperature > 570) safetyStatus = 'critical';
  else if (coreTemperature > 480) safetyStatus = 'warning';
  
  // Generate regulatory alerts based on conditions
  const regulatoryAlerts = [...previousData.regulatoryAlerts];
  
  // Randomly add a new alert occasionally
  if (Math.random() < 0.05) {
    const alertTypes = [
      {
        message: "Control rod adjustment rate exceeds recommended threshold",
        severity: "info" as const,
        source: "24-052"
      },
      {
        message: "Neutron flux fluctuation requires documentation per regulation",
        severity: "info" as const,
        source: "25-018"
      },
      {
        message: "Quarterly coolant system inspection due in 14 days",
        severity: "info" as const,
        source: "24-079"
      }
    ];
    
    if (safetyStatus === 'warning') {
      alertTypes.push({
        message: "Core temperature approaching operational limits",
        severity: "warning" as const,
        source: "25-022"
      });
    }
    
    if (safetyStatus === 'critical') {
      alertTypes.push({
        message: "IMMEDIATE ACTION REQUIRED: Core temperature exceeds safety parameters",
        severity: "critical" as const,
        source: "25-001"
      });
    }
    
    const newAlert = alertTypes[Math.floor(Math.random() * alertTypes.length)];
    regulatoryAlerts.unshift({
      id: Date.now().toString(),
      timestamp: Date.now(),
      ...newAlert
    });
  }
  
  // Keep only the 10 most recent alerts
  while (regulatoryAlerts.length > 10) {
    regulatoryAlerts.pop();
  }
  
  return {
    timestamp: Date.now(),
    coreTemperature,
    neutronFlux,
    coolantFlow,
    controlRodPosition,
    powerOutput,
    containmentPressure,
    safetyStatus,
    regulatoryAlerts
  };
};

export const ReactorDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [systemMode, setSystemMode] = useState<'normal' | 'maintenance' | 'shutdown'>('normal');
  const [controlRodPosition, setControlRodPosition] = useState(40); // 0-100, starting at 40%
  
  const [reactorData, setReactorData] = useState<ReactorData>({
    timestamp: Date.now(),
    coreTemperature: 350,
    neutronFlux: 75,
    coolantFlow: 85,
    controlRodPosition: controlRodPosition,
    powerOutput: 95,
    containmentPressure: 23,
    safetyStatus: 'normal',
    regulatoryAlerts: [{
      id: '1',
      message: "System initialized - welcome to REACTOR.ONE monitoring platform",
      severity: "info",
      source: "SYSTEM",
      timestamp: Date.now()
    }]
  });
  
  // Update control rod position
  const updateControlRods = (position: number) => {
    setControlRodPosition(position);
  };
  
  // Simulate data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setReactorData(prevData => 
        simulateReactorData(prevData, controlRodPosition, systemMode)
      );
    }, 1500);
    
    return () => clearInterval(interval);
  }, [controlRodPosition, systemMode]);
  
  return (
    <ReactorDataContext.Provider value={{ 
      reactorData, 
      updateControlRods, 
      systemMode, 
      setSystemMode 
    }}>
      {children}
    </ReactorDataContext.Provider>
  );
};

export const useReactorData = () => {
  const context = useContext(ReactorDataContext);
  if (context === undefined) {
    throw new Error('useReactorData must be used within a ReactorDataProvider');
  }
  return context;
};
