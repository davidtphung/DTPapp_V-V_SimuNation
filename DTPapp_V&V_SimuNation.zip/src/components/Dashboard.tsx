import React from 'react';
import { useReactorData } from '../context/ReactorDataContext';
import { Cpu, Droplets, Gauge, Squircle, Thermometer, Zap } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import ReactorMetricCard from './ReactorMetricCard';
import ControlRodSlider from './ControlRodSlider';
import ReactorLineChart from './ReactorLineChart';
import AlertPanel from './AlertPanel';

const Dashboard: React.FC = () => {
  const { reactorData, systemMode } = useReactorData();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <div className="col-span-1 md:col-span-2 lg:col-span-3">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Reactor Monitoring Dashboard</h1>
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          {systemMode === 'normal' && 'System running in normal operation mode'}
          {systemMode === 'maintenance' && 'System running in maintenance mode - reduced output'}
          {systemMode === 'shutdown' && 'System in shutdown mode - minimal activity'}
        </p>
      </div>

      {/* Status summary card */}
      <div className="col-span-1 md:col-span-2 lg:col-span-3 bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">System Status</h2>
            <div className="flex items-center mt-1">
              <div className={`h-3 w-3 rounded-full mr-2 ${
                reactorData.safetyStatus === 'normal' ? 'bg-green-500' :
                reactorData.safetyStatus === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
              }`}></div>
              <span className={`text-sm font-medium ${
                reactorData.safetyStatus === 'normal' ? 'text-green-600 dark:text-green-400' :
                reactorData.safetyStatus === 'warning' ? 'text-yellow-600 dark:text-yellow-400' : 'text-red-600 dark:text-red-400'
              }`}>
                {reactorData.safetyStatus === 'normal' ? 'Normal Operating Parameters' :
                 reactorData.safetyStatus === 'warning' ? 'Warning: Parameter Thresholds Approaching' : 
                 'Critical: Safety Parameters Exceeded'}
              </span>
            </div>
          </div>
          
          {reactorData.safetyStatus !== 'normal' && (
            <div className="mt-3 md:mt-0 flex items-center px-3 py-1.5 bg-red-100 dark:bg-red-900/50 rounded-md border border-red-200 dark:border-red-800">
              <Squircle className="h-4 w-4 text-red-600 dark:text-red-400 mr-2" />
              <span className="text-sm font-medium text-red-600 dark:text-red-400">
                {reactorData.safetyStatus === 'warning' ? 'Operator attention required' : 'Immediate action required'}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Metric cards */}
      <ReactorMetricCard 
        title="Core Temperature" 
        value={reactorData.coreTemperature.toFixed(1)}
        unit="°C"
        icon={<Thermometer className="h-5 w-5 text-red-500" />}
        trend={(reactorData.coreTemperature > 500) ? 'critical' : (reactorData.coreTemperature > 450) ? 'warning' : 'normal'}
      />
      
      <ReactorMetricCard 
        title="Neutron Flux" 
        value={reactorData.neutronFlux.toFixed(1)}
        unit="n/cm²·s × 10¹⁴"
        icon={<Zap className="h-5 w-5 text-purple-500" />}
        trend="normal"
      />
      
      <ReactorMetricCard 
        title="Coolant Flow" 
        value={reactorData.coolantFlow.toFixed(1)}
        unit="m³/h × 10³"
        icon={<Droplets className="h-5 w-5 text-blue-500" />}
        trend="normal"
      />
      
      <ReactorMetricCard 
        title="Power Output" 
        value={reactorData.powerOutput.toFixed(1)}
        unit="MW"
        icon={<Gauge className="h-5 w-5 text-green-500" />}
        trend="normal"
      />
      
      <ReactorMetricCard 
        title="Containment Pressure" 
        value={reactorData.containmentPressure.toFixed(2)}
        unit="kPa × 10²"
        icon={<Cpu className="h-5 w-5 text-amber-500" />}
        trend={(reactorData.containmentPressure > 30) ? 'warning' : 'normal'}
      />
      
      {/* Control rod adjustment */}
      <div className="col-span-1 md:col-span-2 lg:col-span-3 bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Control Rod Position</h2>
        <ControlRodSlider />
      </div>
      
      {/* Charts */}
      <div className="col-span-1 md:col-span-2 lg:col-span-3 bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Reactor Telemetry</h2>
        <div className="h-64 mb-3">
          <ReactorLineChart />
        </div>
      </div>
      
      {/* Regulatory alerts */}
      <div className="col-span-1 md:col-span-2 lg:col-span-3 bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">NRC Regulatory Notifications</h2>
        <AlertPanel alerts={reactorData.regulatoryAlerts} />
      </div>
    </div>
  );
};

export default Dashboard;
