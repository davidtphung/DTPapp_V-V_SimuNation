import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useReactorData } from '../context/ReactorDataContext';

const ReactorLineChart: React.FC = () => {
  const { reactorData } = useReactorData();

  // Sample data for the chart
  const data = [
    { time: '09:00', coreTemperature: 350, neutronFlux: 70, powerOutput: 90 },
    { time: '09:05', coreTemperature: 360, neutronFlux: 75, powerOutput: 92 },
    { time: '09:10', coreTemperature: 365, neutronFlux: 73, powerOutput: 94 },
    { time: '09:15', coreTemperature: 370, neutronFlux: 78, powerOutput: 95 },
    { time: '09:20', coreTemperature: 380, neutronFlux: 80, powerOutput: 97 },
    { time: '09:25', coreTemperature: 385, neutronFlux: 82, powerOutput: 98 },
    { time: '09:30', coreTemperature: reactorData.coreTemperature, neutronFlux: reactorData.neutronFlux, powerOutput: reactorData.powerOutput },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
        <XAxis 
          dataKey="time" 
          tick={{ fill: '#9CA3AF' }}
          axisLine={{ stroke: '#4B5563' }}
        />
        <YAxis 
          yAxisId="left"
          tick={{ fill: '#9CA3AF' }}
          axisLine={{ stroke: '#4B5563' }}
        />
        <YAxis 
          yAxisId="right" 
          orientation="right"
          tick={{ fill: '#9CA3AF' }}
          axisLine={{ stroke: '#4B5563' }}
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'rgba(17, 24, 39, 0.8)',
            border: 'none',
            borderRadius: '4px',
            color: '#F9FAFB'
          }} 
        />
        <Legend />
        <Line
          yAxisId="left"
          type="monotone"
          dataKey="coreTemperature"
          name="Core Temp (°C)"
          stroke="#EF4444"
          activeDot={{ r: 8 }}
          strokeWidth={2}
        />
        <Line
          yAxisId="left"
          type="monotone"
          dataKey="neutronFlux"
          name="Neutron Flux"
          stroke="#A855F7"
          strokeWidth={2}
        />
        <Line
          yAxisId="right"
          type="monotone"
          dataKey="powerOutput"
          name="Power (MW)"
          stroke="#10B981"
          strokeWidth={2}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default ReactorLineChart;
