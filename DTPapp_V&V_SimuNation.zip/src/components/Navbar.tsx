import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, Menu, Moon, Squircle, Sun, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useReactorData } from '../context/ReactorDataContext';

interface NavbarProps {
  toggleSidebar?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar }) => {
  const { darkMode, toggleDarkMode } = useTheme();
  const { reactorData } = useReactorData();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const alertCount = reactorData.regulatoryAlerts.filter(
    alert => alert.severity === 'warning' || alert.severity === 'critical'
  ).length;

  const handleToggleSidebar = () => {
    if (toggleSidebar) {
      toggleSidebar();
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-4 py-2.5 sticky top-0 z-10">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <button
            onClick={handleToggleSidebar}
            className="md:hidden p-2 mr-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none"
            aria-label="Toggle sidebar"
          >
            <Menu className="h-6 w-6 text-gray-500 dark:text-gray-400" />
          </button>
          <Link to="/" className="flex items-center">
            <Activity className="h-6 w-6 text-blue-600 dark:text-blue-500 mr-2" />
            <span className="text-xl font-semibold text-gray-900 dark:text-white">REACTOR.ONE</span>
          </Link>
        </div>

        <div className="flex items-center space-x-2">
          {alertCount > 0 && (
            <div className="relative">
              <Squircle className="h-6 w-6 text-amber-500" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                {alertCount}
              </span>
            </div>
          )}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none"
          >
            {darkMode ? (
              <Sun className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            ) : (
              <Moon className="h-5 w-5 text-gray-500" />
            )}
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
