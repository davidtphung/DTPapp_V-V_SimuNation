import React from 'react';
import { useAppMode } from '../context/AppModeContext';
import { ArrowUpRight } from 'lucide-react';

const KidsModeAlert: React.FC = () => {
  const { appMode, toggleAppMode } = useAppMode();
  
  if (appMode === 'expert') return null;
  
  return (
    <div className="bg-indigo-100 dark:bg-indigo-900/40 rounded-lg p-4 mb-6 border-2 border-indigo-200 dark:border-indigo-800">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
        <div>
          <h3 className="font-bold text-indigo-800 dark:text-indigo-200 text-lg">Kids Learning Mode Active!</h3>
          <p className="text-indigo-700 dark:text-indigo-300 mt-1">
            You're using the simplified educational version of REACTOR.ONE designed for learning
          </p>
        </div>
        <button 
          onClick={toggleAppMode}
          className="mt-3 sm:mt-0 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center"
        >
          Switch to Expert Mode
          <ArrowUpRight className="ml-1 h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default KidsModeAlert;
