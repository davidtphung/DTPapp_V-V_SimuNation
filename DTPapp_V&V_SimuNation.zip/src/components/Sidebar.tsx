import React from 'react';
import { NavLink } from 'react-router-dom';
import { ChartBarBig, House, List, Settings, Squircle, X } from 'lucide-react';
import { useReactorData } from '../context/ReactorDataContext';

interface SidebarProps {
  closeSidebar?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ closeSidebar }) => {
  const { systemMode, setSystemMode } = useReactorData();

  return (
    <div className="h-full w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 overflow-y-auto relative">
      {closeSidebar && (
        <button
          onClick={closeSidebar}
          className="md:hidden absolute top-4 right-4 p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none"
          aria-label="Close sidebar"
        >
          <X className="h-5 w-5 text-gray-500 dark:text-gray-400" />
        </button>
      )}
      
      <div className="p-4">
        <h3 className="mb-2 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
          System Mode
        </h3>
        <div className="flex flex-col space-y-2 mb-6">
          <button
            className={`px-3 py-2 rounded-md text-sm font-medium ${
              systemMode === 'normal'
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100'
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            onClick={() => setSystemMode('normal')}
          >
            Normal Operation
          </button>
          <button
            className={`px-3 py-2 rounded-md text-sm font-medium ${
              systemMode === 'maintenance'
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            onClick={() => setSystemMode('maintenance')}
          >
            Maintenance Mode
          </button>
          <button
            className={`px-3 py-2 rounded-md text-sm font-medium ${
              systemMode === 'shutdown'
                ? 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100'
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            onClick={() => setSystemMode('shutdown')}
          >
            Shutdown Mode
          </button>
        </div>

        <h3 className="mb-2 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
          Navigation
        </h3>
        <nav className="space-y-1">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                isActive
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`
            }
            end
          >
            <House className="h-4 w-4 mr-3" />
            Dashboard
          </NavLink>
          <NavLink
            to="/assumptions"
            className={({ isActive }) =>
              `flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                isActive
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`
            }
          >
            <List className="h-4 w-4 mr-3" />
            Assumption Tracker
          </NavLink>
          <NavLink
            to="/reports"
            className={({ isActive }) =>
              `flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                isActive
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`
            }
          >
            <ChartBarBig className="h-4 w-4 mr-3" />
            Reports
          </NavLink>
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              `flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                isActive
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`
            }
          >
            <Settings className="h-4 w-4 mr-3" />
            Settings
          </NavLink>
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
