import React from 'react';
import { ArrowRight, TrendingDown, TrendingUp } from 'lucide-react';

interface ReactorMetricCardProps {
  title: string;
  value: string;
  unit: string;
  icon: React.ReactNode;
  trend: 'normal' | 'warning' | 'critical';
}

const ReactorMetricCard: React.FC<ReactorMetricCardProps> = ({
  title,
  value,
  unit,
  icon,
  trend
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
      <div className="flex justify-between">
        <div className="flex items-center">
          <div className="mr-3">{icon}</div>
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">{title}</h3>
        </div>
        <div className={`flex items-center ${
          trend === 'normal' ? 'text-green-500' : 
          trend === 'warning' ? 'text-amber-500' : 'text-red-500'
        }`}>
          {trend === 'normal' ? (
            <ArrowRight className="h-4 w-4" />
          ) : trend === 'warning' ? (
            <TrendingUp className="h-4 w-4" />
          ) : (
            <TrendingUp className="h-4 w-4" />
          )}
        </div>
      </div>
      <div className="mt-2 flex items-baseline">
        <p className="text-2xl font-semibold text-gray-900 dark:text-white">{value}</p>
        <p className="ml-1 text-sm text-gray-700 dark:text-gray-300">{unit}</p>
      </div>
    </div>
  );
};

export default ReactorMetricCard;
