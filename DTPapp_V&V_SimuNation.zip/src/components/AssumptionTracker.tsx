import React, { useState } from 'react';
import { CircleCheck, CircleHelp, ClipboardCheck, Download, ExternalLink, FileSpreadsheet, List, Squircle } from 'lucide-react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { format } from 'date-fns';

interface Assumption {
  id: string;
  description: string;
  category: 'material' | 'thermal' | 'physics';
  status: 'unverified' | 'simulated' | 'tested' | 'approved';
  nrcReference: string;
  confidence: number;
  lastUpdated: string;
}

interface AssumptionHistory {
  id: string;
  assumptionId: string;
  description: string;
  changeType: 'created' | 'updated' | 'reviewed';
  changedBy: string;
  previousStatus?: string;
  newStatus?: string;
  previousConfidence?: number;
  newConfidence?: number;
  changeDate: string;
  notes: string;
}

const initialAssumptions: Assumption[] = [
  {
    id: '1',
    description: 'Core material withstands temperatures up to 850°C without structural compromise',
    category: 'material',
    status: 'tested',
    nrcReference: '24-034',
    confidence: 87,
    lastUpdated: '2025-02-15'
  },
  {
    id: '2',
    description: 'Passive cooling system provides minimum 72hr grace period under LOOP conditions',
    category: 'thermal',
    status: 'simulated',
    nrcReference: '24-056',
    confidence: 76,
    lastUpdated: '2025-01-28'
  },
  {
    id: '3',
    description: 'Neutron reflector efficiency maintains 92% over 10-year operational period',
    category: 'physics',
    status: 'unverified',
    nrcReference: 'Pending',
    confidence: 41,
    lastUpdated: '2025-03-07'
  },
  {
    id: '4',
    description: 'Containment structure withstands 2.1 MPa internal pressure',
    category: 'material',
    status: 'approved',
    nrcReference: '24-027',
    confidence: 95,
    lastUpdated: '2024-11-12'
  },
  {
    id: '5',
    description: 'Thermal stratification in coolant pool remains below 35°C differential',
    category: 'thermal',
    status: 'simulated',
    nrcReference: '25-012',
    confidence: 68,
    lastUpdated: '2025-02-23'
  },
];

// Sample history data
const assumptionHistoryData: AssumptionHistory[] = [
  {
    id: 'h1',
    assumptionId: '1',
    description: 'Core material temperature threshold assessment',
    changeType: 'updated',
    changedBy: 'Dr. Sarah Chen',
    previousStatus: 'simulated',
    newStatus: 'tested',
    previousConfidence: 72,
    newConfidence: 87,
    changeDate: '2025-02-15',
    notes: 'Updated based on material test results from laboratory'
  },
  {
    id: 'h2',
    assumptionId: '2',
    description: 'Passive cooling system LOOP response',
    changeType: 'updated',
    changedBy: 'Dr. James Rodriguez',
    previousStatus: 'unverified',
    newStatus: 'simulated',
    previousConfidence: 35,
    newConfidence: 76,
    changeDate: '2025-01-28',
    notes: 'Computational fluid dynamics simulation completed'
  },
  {
    id: 'h3',
    assumptionId: '3',
    description: 'Neutron reflector efficiency initial assessment',
    changeType: 'created',
    changedBy: 'Dr. Michael Wei',
    previousStatus: undefined,
    newStatus: 'unverified',
    previousConfidence: undefined,
    newConfidence: 41,
    changeDate: '2025-03-07',
    notes: 'Initial theoretical calculation based on material composition'
  },
  {
    id: 'h4',
    assumptionId: '4',
    description: 'Containment pressure threshold approval',
    changeType: 'updated',
    changedBy: 'Dr. Elena Fischer',
    previousStatus: 'tested',
    newStatus: 'approved',
    previousConfidence: 91,
    newConfidence: 95,
    changeDate: '2024-11-12',
    notes: 'NRC review complete - full approval granted'
  },
  {
    id: 'h5',
    assumptionId: '5',
    description: 'Thermal stratification assessment update',
    changeType: 'reviewed',
    changedBy: 'Dr. Anthony Park',
    previousStatus: 'simulated',
    newStatus: 'simulated',
    previousConfidence: 65,
    newConfidence: 68,
    changeDate: '2025-02-23',
    notes: 'Reviewed against latest thermal hydraulic simulations'
  },
  {
    id: 'h6',
    assumptionId: '1',
    description: 'Core material temperature - initial simulation',
    changeType: 'created',
    changedBy: 'Dr. Sarah Chen',
    previousStatus: undefined,
    newStatus: 'simulated',
    previousConfidence: undefined,
    newConfidence: 72,
    changeDate: '2024-12-05',
    notes: 'Initial material simulation using finite element analysis'
  },
  {
    id: 'h7',
    assumptionId: '2',
    description: 'Passive cooling system - initial documentation',
    changeType: 'created',
    changedBy: 'Dr. James Rodriguez',
    previousStatus: undefined,
    newStatus: 'unverified',
    previousConfidence: undefined,
    newConfidence: 35,
    changeDate: '2024-11-19',
    notes: 'Initial concept based on industry benchmarks'
  },
];

// Function to generate a simulated NRC document URL that points to a PDF
const getNrcDocumentUrl = (sourceId: string) => {
  if (!sourceId || sourceId === 'Pending') {
    return undefined;
  }
  
  const match = sourceId.match(/(\d{2})-(\d{3})/);
  if (match) {
    const year = match[1] === '24' ? '2024' : '2025';
    return `https://www.nrc.gov/cdn/doc-collection-news/${year}/${sourceId}.pdf`;
  }
  
  return undefined;
};

const getCategoryLabel = (category: string) => {
  switch (category) {
    case 'material': return 'Material';
    case 'thermal': return 'Thermal';
    case 'physics': return 'Physics';
    default: return category;
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case 'unverified': return 'Unverified';
    case 'simulated': return 'Simulated';
    case 'tested': return 'Tested';
    case 'approved': return 'Approved';
    default: return status;
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'unverified': 
      return <CircleHelp className="h-5 w-5 text-gray-400" />;
    case 'simulated': 
      return <Squircle className="h-5 w-5 text-blue-500" />;
    case 'tested': 
      return <ClipboardCheck className="h-5 w-5 text-yellow-500" />;
    case 'approved': 
      return <CircleCheck className="h-5 w-5 text-green-500" />;
    default: 
      return null;
  }
};

const AssumptionTracker: React.FC = () => {
  const [filter, setFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [selectedAssumption, setSelectedAssumption] = useState<string | null>(null);
  
  const filteredAssumptions = initialAssumptions.filter(assumption => {
    const matchesFilter = filter === 'all' || assumption.category === filter || assumption.status === filter;
    const matchesSearch = searchQuery === '' || 
      assumption.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      assumption.nrcReference.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  // Filter history data based on selected assumption
  const filteredHistory = assumptionHistoryData.filter(history => {
    if (selectedAssumption) {
      return history.assumptionId === selectedAssumption;
    }
    return true;
  });

  // Function to download assumption history as Excel
  const downloadHistoryAsExcel = () => {
    // Prepare data for export
    const dataToExport = filteredHistory.map(history => ({
      'ID': history.id,
      'Assumption ID': history.assumptionId,
      'Description': history.description,
      'Change Type': history.changeType,
      'Changed By': history.changedBy,
      'Previous Status': history.previousStatus || 'N/A',
      'New Status': history.newStatus || 'N/A',
      'Previous Confidence': history.previousConfidence || 'N/A',
      'New Confidence': history.newConfidence || 'N/A',
      'Date': history.changeDate,
      'Notes': history.notes
    }));
    
    // Create workbook and worksheet
    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Assumption History");
    
    // Set column widths for better readability
    const colWidths = [
      { wch: 5 }, // ID
      { wch: 12 }, // Assumption ID
      { wch: 40 }, // Description
      { wch: 12 }, // Change Type
      { wch: 15 }, // Changed By
      { wch: 15 }, // Previous Status
      { wch: 15 }, // New Status
      { wch: 18 }, // Previous Confidence
      { wch: 15 }, // New Confidence
      { wch: 12 }, // Date
      { wch: 40 }, // Notes
    ];
    ws['!cols'] = colWidths;
    
    // Generate Excel file
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    // Save file
    saveAs(blob, `assumption-history-log-${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Assumption Tracker & V&V Matrix</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Track technical assumptions and their verification & validation status
        </p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search assumptions or NRC document numbers..."
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                filter === 'all' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setFilter('all')}
            >
              All
            </button>
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                filter === 'material' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setFilter('material')}
            >
              Material
            </button>
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                filter === 'thermal' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setFilter('thermal')}
            >
              Thermal
            </button>
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                filter === 'physics' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setFilter('physics')}
            >
              Physics
            </button>
          </div>
        </div>
        
        <div className="overflow-auto max-h-[600px]">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900 sticky top-0">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-16">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Assumption
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-24">
                  Category
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-32">
                  NRC Document Number
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-24">
                  Confidence
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredAssumptions.map((assumption) => (
                <tr 
                  key={assumption.id} 
                  className="hover:bg-gray-50 dark:hover:bg-gray-750 cursor-pointer"
                  onClick={() => {
                    setSelectedAssumption(assumption.id);
                    setShowHistory(true);
                  }}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center justify-center">
                      {getStatusIcon(assumption.status)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900 dark:text-white">{assumption.description}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">Updated: {assumption.lastUpdated}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      assumption.category === 'material' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100' :
                      assumption.category === 'thermal' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100' :
                      'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                    }`}>
                      {getCategoryLabel(assumption.category)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {getNrcDocumentUrl(assumption.nrcReference) ? (
                      <a 
                        href={getNrcDocumentUrl(assumption.nrcReference)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        {assumption.nrcReference}
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </a>
                    ) : (
                      <span className="text-gray-500 dark:text-gray-400">{assumption.nrcReference}</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                        <div 
                          className={`h-2.5 rounded-full ${
                            assumption.confidence >= 80 ? 'bg-green-500' :
                            assumption.confidence >= 60 ? 'bg-yellow-500' :
                            'bg-red-500'
                          }`}
                          style={{ width: `${assumption.confidence}%` }}
                        ></div>
                      </div>
                      <span className="ml-2 text-xs font-medium text-gray-500 dark:text-gray-400">
                        {assumption.confidence}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* History Log Panel */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 mb-6">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <List className="h-5 w-5 text-blue-500 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              Assumption History Log
              {selectedAssumption && ` - ID: ${selectedAssumption}`}
            </h2>
          </div>
          <div className="flex gap-2">
            {selectedAssumption && (
              <button
                onClick={() => setSelectedAssumption(null)}
                className="px-3 py-1.5 rounded-md text-sm font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100 transition-colors"
              >
                Show All
              </button>
            )}
            <button
              onClick={downloadHistoryAsExcel}
              className="flex items-center px-3 py-1.5 rounded-md text-sm font-medium bg-green-600 text-white hover:bg-green-700 transition-colors"
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Export Excel
            </button>
          </div>
        </div>
        
        <div className="overflow-auto max-h-[400px]">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900 sticky top-0">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Assumption
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Change
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  By
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status Change
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Confidence Change
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredHistory.map((history) => (
                <tr key={history.id}>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {history.changeDate}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                    {history.description}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      history.changeType === 'created' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                      history.changeType === 'updated' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' :
                      'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100'
                    }`}>
                      {history.changeType.charAt(0).toUpperCase() + history.changeType.slice(1)}
                    </span>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {history.changedBy}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm">
                    {history.previousStatus && history.newStatus ? (
                      <div className="flex items-center">
                        <span className="text-gray-500 dark:text-gray-400">{getStatusLabel(history.previousStatus)}</span>
                        <svg className="w-4 h-4 mx-1 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                        <span className="text-gray-900 dark:text-white">{getStatusLabel(history.newStatus)}</span>
                      </div>
                    ) : (
                      <span className="text-gray-900 dark:text-white">
                        {history.newStatus ? getStatusLabel(history.newStatus) : 'N/A'}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm">
                    {history.previousConfidence !== undefined && history.newConfidence !== undefined ? (
                      <div className="flex items-center">
                        <span className="text-gray-500 dark:text-gray-400">{history.previousConfidence}%</span>
                        <svg className="w-4 h-4 mx-1 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                        <span className={`${
                          history.newConfidence > (history.previousConfidence || 0) 
                            ? 'text-green-600 dark:text-green-400' 
                            : history.newConfidence < (history.previousConfidence || 0)
                              ? 'text-red-600 dark:text-red-400'
                              : 'text-gray-900 dark:text-white'
                        }`}>
                          {history.newConfidence}%
                        </span>
                      </div>
                    ) : (
                      <span className="text-gray-900 dark:text-white">
                        {history.newConfidence !== undefined ? `${history.newConfidence}%` : 'N/A'}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4 mb-6">
        <h3 className="font-semibold text-blue-800 dark:text-blue-100 mb-2">NRC Feedback on Assumptions</h3>
        <p className="text-blue-700 dark:text-blue-200 text-sm">
          The NRC has provided feedback on recent assumption submissions. Core material temperature assumptions (<a href="https://www.nrc.gov/cdn/doc-collection-news/2024/24-034.pdf" target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-300 hover:underline inline-flex items-center">24-034 <ExternalLink className="ml-1 h-3 w-3" /></a>) have been approved for use in safety analysis. Passive cooling assumptions require additional experimental validation per <a href="https://www.nrc.gov/reading-rm/doc-collections/reg-guides/power-reactors/rg/01-203/" target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-300 hover:underline inline-flex items-center">Regulatory Guide 1.203 <ExternalLink className="ml-1 h-3 w-3" /></a>.
        </p>
      </div>
      
      <div className="text-sm text-gray-500 dark:text-gray-400 italic">
        Data in this module is simulated for educational purposes only. Real reactor design and analysis requires comprehensive engineering validation under regulatory oversight.
      </div>
    </div>
  );
};

export default AssumptionTracker;
