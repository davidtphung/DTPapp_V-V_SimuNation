import React from 'react';
import { CircleAlert, ExternalLink, Info, Squircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Alert {
  id: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  source: string;
  timestamp: number;
}

interface AlertPanelProps {
  alerts: Alert[];
}

// Function to generate a simulated NRC document URL that points to a PDF
const getNrcDocumentUrl = (sourceId: string) => {
  if (!sourceId || sourceId === 'SYSTEM' || sourceId === 'Pending') {
    return undefined;
  }
  
  const match = sourceId.match(/(\d{2})-(\d{3})/);
  if (match) {
    const year = match[1] === '24' ? '2024' : '2025';
    return `https://www.nrc.gov/cdn/doc-collection-news/${year}/${sourceId}.pdf`;
  }
  
  return undefined;
};

const AlertPanel: React.FC<AlertPanelProps> = ({ alerts }) => {
  if (alerts.length === 0) {
    return (
      <div className="text-center py-8 text-gray-600 dark:text-gray-400">
        No regulatory alerts to display
      </div>
    );
  }

  return (
    <div className="overflow-auto max-h-[300px] -mx-4">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-900 sticky top-0">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-300 uppercase tracking-wider">
              Severity
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-300 uppercase tracking-wider">
              Message
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-300 uppercase tracking-wider">
              NRC Document Number
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-300 uppercase tracking-wider">
              Time
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {alerts.map((alert) => (
            <tr key={alert.id} className="hover:bg-gray-50 dark:hover:bg-gray-750">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  {alert.severity === 'info' && <Info className="h-5 w-5 text-blue-500" />}
                  {alert.severity === 'warning' && <Squircle className="h-5 w-5 text-yellow-500" />}
                  {alert.severity === 'critical' && <CircleAlert className="h-5 w-5 text-red-500" />}
                  <span className={`ml-2 text-xs font-medium ${
                    alert.severity === 'info' ? 'text-blue-600 dark:text-blue-400' :
                    alert.severity === 'warning' ? 'text-yellow-600 dark:text-yellow-400' : 'text-red-600 dark:text-red-400'
                  }`}>
                    {alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1)}
                  </span>
                </div>
              </td>
              <td className="px-6 py-4 text-sm text-gray-800 dark:text-gray-200">
                {alert.message}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                {getNrcDocumentUrl(alert.source) ? (
                  <a 
                    href={getNrcDocumentUrl(alert.source)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    {alert.source}
                    <ExternalLink className="ml-1 h-3 w-3" />
                  </a>
                ) : (
                  <span className="text-gray-600 dark:text-gray-400">{alert.source}</span>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                {formatDistanceToNow(alert.timestamp, { addSuffix: true })}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AlertPanel;
