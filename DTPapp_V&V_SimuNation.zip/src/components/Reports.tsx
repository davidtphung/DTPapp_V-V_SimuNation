import React, { useState, useEffect } from 'react';
import { useReactorData } from '../context/ReactorDataContext';
import { useAppMode } from '../context/AppModeContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { BatteryCharging, Calendar, Cpu, Download, ExternalLink, FileSpreadsheet, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { format, subDays, subMonths, subYears } from 'date-fns';

interface ReportPeriod {
  id: string;
  name: string;
  days: number;
}

interface ArchiveReport {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  fileSize: string;
  fileType: 'excel' | 'pdf';
  fileName: string;
  sourceUrl: string;
  showSourceLink?: boolean;
}

const Reports: React.FC = () => {
  const { reactorData, systemMode } = useReactorData();
  const { appMode } = useAppMode();
  const [selectedReport, setSelectedReport] = useState<string>('performance');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('7d');
  const [isExporting, setIsExporting] = useState(false);
  const [performanceData, setPerformanceData] = useState<any[]>([]);
  const [safetyData, setSafetyData] = useState<any[]>([]);

  // Sample data for reports
  const reportPeriods: ReportPeriod[] = [
    { id: '1d', name: 'Last 24 Hours', days: 1 },
    { id: '7d', name: 'Last 7 Days', days: 7 },
    { id: '30d', name: 'Last 30 Days', days: 30 },
    { id: '90d', name: 'Last Quarter', days: 90 },
    { id: '365d', name: 'Last Year', days: 365 },
  ];

  // Generate performance data based on selected period
  useEffect(() => {
    const generatePerformanceData = (periodId: string) => {
      const data = [];
      const now = new Date();
      let interval: 'hourly' | 'daily' | 'weekly' | 'monthly' = 'daily';
      let dataPoints = 7; // default
      let dateFormat = 'MMM dd';
      
      // Set data generation parameters based on period
      switch(periodId) {
        case '1d':
          interval = 'hourly';
          dataPoints = 24;
          dateFormat = 'HH:mm';
          break;
        case '7d':
          interval = 'daily';
          dataPoints = 7;
          dateFormat = 'MMM dd';
          break;
        case '30d':
          interval = 'daily';
          dataPoints = 30;
          dateFormat = 'MMM dd';
          break;
        case '90d':
          interval = 'weekly';
          dataPoints = 13;
          dateFormat = 'MMM dd';
          break;
        case '365d':
          interval = 'monthly';
          dataPoints = 12;
          dateFormat = 'MMM yyyy';
          break;
      }
      
      // Generate data with appropriate time intervals
      for (let i = 0; i < dataPoints; i++) {
        let date = new Date();
        
        if (interval === 'hourly') {
          date = new Date(now.getTime() - (i * 60 * 60 * 1000));
        } else if (interval === 'daily') {
          date = subDays(now, i);
        } else if (interval === 'weekly') {
          date = subDays(now, i * 7);
        } else if (interval === 'monthly') {
          date = subMonths(now, i);
        }
        
        // Base values with some seasonality for longer periods
        let baseEfficiency = 92;
        let baseOutput = 98;
        let baseTemp = 420;
        
        // Add seasonality for longer periods
        if (interval === 'monthly') {
          // Summer months have lower efficiency due to high ambient temperature
          const month = date.getMonth();
          if (month >= 5 && month <= 8) { // June-September
            baseEfficiency -= 4;
            baseTemp += 15;
          } else if (month <= 1 || month === 11) { // Dec-Feb
            baseOutput -= 5;
            baseTemp -= 10;
          }
        }
        
        // Add some randomness for realism
        const noise = Math.random() * 6 - 3;
        const noise2 = Math.random() * 8 - 4;
        const noise3 = Math.random() * 10 - 5;
        
        data.unshift({
          date: format(date, dateFormat),
          efficiency: Math.round(baseEfficiency + noise),
          output: Math.round(baseOutput + noise2),
          temperature: Math.round(baseTemp + noise3),
          // Store full date for sorting
          fullDate: date
        });
      }
      
      return data;
    };
    
    const generateSafetyData = (periodId: string) => {
      const data = [];
      const now = new Date();
      let interval: 'hourly' | 'daily' | 'weekly' | 'monthly' = 'daily';
      let dataPoints = 7; // default
      let dateFormat = 'MMM dd';
      
      // Set data generation parameters based on period
      switch(periodId) {
        case '1d':
          interval = 'hourly';
          dataPoints = 24;
          dateFormat = 'HH:mm';
          break;
        case '7d':
          interval = 'daily';
          dataPoints = 7;
          dateFormat = 'MMM dd';
          break;
        case '30d':
          interval = 'daily';
          dataPoints = 30;
          dateFormat = 'MMM dd';
          break;
        case '90d':
          interval = 'weekly';
          dataPoints = 13;
          dateFormat = 'MMM dd';
          break;
        case '365d':
          interval = 'monthly';
          dataPoints = 12;
          dateFormat = 'MMM yyyy';
          break;
      }
      
      // Generate data with appropriate time intervals
      for (let i = 0; i < dataPoints; i++) {
        let date = new Date();
        
        if (interval === 'hourly') {
          date = new Date(now.getTime() - (i * 60 * 60 * 1000));
        } else if (interval === 'daily') {
          date = subDays(now, i);
        } else if (interval === 'weekly') {
          date = subDays(now, i * 7);
        } else if (interval === 'monthly') {
          date = subMonths(now, i);
        }
        
        // Generate realistic safety data
        // More tests on regular maintenance periods (beginning of month)
        let baseTests = 12;
        let baseWarnings = 2;
        let baseIncidents = 0;
        
        if (interval === 'monthly' || interval === 'weekly') {
          // More tests during quarterly maintenance periods
          if (date.getMonth() % 3 === 0) {
            baseTests += 8;
          }
        }
        
        if (date.getDate() <= 5) {
          // Beginning of month has more tests
          baseTests += 4;
        }
        
        // Add some randomness
        const testsNoise = Math.floor(Math.random() * 5);
        const warningsNoise = Math.floor(Math.random() * 3);
        // Extremely rare incidents
        const incidentRandom = Math.random();
        const incidents = incidentRandom > 0.95 ? 1 : 0;
        
        data.unshift({
          date: format(date, dateFormat),
          incidents: incidents,
          warnings: Math.max(0, Math.floor(baseWarnings + warningsNoise - incidents * 2)),
          tests: Math.max(5, Math.floor(baseTests + testsNoise + incidents * 10)),
          // Store full date for sorting
          fullDate: date
        });
      }
      
      return data;
    };
    
    // Update data when period changes
    setPerformanceData(generatePerformanceData(selectedPeriod));
    setSafetyData(generateSafetyData(selectedPeriod));
  }, [selectedPeriod]);

  // Sample maintenance data
  const maintenanceData = [
    { component: 'Control Rods', lastMaintenance: '2025-02-15', nextDue: '2025-04-15', status: 'Good', nrcRef: 'NRC-RODS-2025-03' },
    { component: 'Coolant Pumps', lastMaintenance: '2025-03-01', nextDue: '2025-05-01', status: 'Good', nrcRef: 'NRC-PUMP-2025-07' },
    { component: 'Heat Exchangers', lastMaintenance: '2025-01-20', nextDue: '2025-03-20', status: 'Due', nrcRef: 'NRC-HEAT-2024-19' },
    { component: 'Pressure Vessels', lastMaintenance: '2025-02-28', nextDue: '2025-08-28', status: 'Good', nrcRef: 'NRC-PRES-2024-11' },
    { component: 'Monitoring Systems', lastMaintenance: '2025-03-10', nextDue: '2025-04-10', status: 'Good', nrcRef: 'NRC-MON-2025-01' },
    { component: 'Emergency Generators', lastMaintenance: '2025-01-15', nextDue: '2025-03-15', status: 'Overdue', nrcRef: 'NRC-GEN-2024-22' },
  ];

  // Archive reports data
  const archiveReports: ArchiveReport[] = [
    {
      id: 'quarterly-operations',
      title: 'Quarterly Operations Report',
      description: 'Comprehensive overview of reactor operations for Q1 2025, including performance metrics, efficiency analysis, and operational statistics.',
      icon: <Calendar className="h-5 w-5 text-blue-500 mr-2" />,
      fileSize: '4.2 MB',
      fileType: 'excel',
      fileName: 'quarterly-operations-q1-2025.xlsx',
      sourceUrl: 'https://www.nrc.gov/docs/simulation/reports/quarterly-operations-q1-2025.html',
      showSourceLink: false
    },
    {
      id: 'energy-output',
      title: 'Energy Output Analysis',
      description: 'Detailed analysis of energy generation efficiency, output fluctuations, and performance optimization opportunities.',
      icon: <BatteryCharging className="h-5 w-5 text-green-500 mr-2" />,
      fileSize: '3.7 MB',
      fileType: 'pdf',
      fileName: 'energy-output-2025-03.pdf',
      sourceUrl: 'https://www.nrc.gov/docs/simulation/reports/energy-output-2025-03.html',
      showSourceLink: false
    },
    {
      id: 'system-diagnostics',
      title: 'System Diagnostics Report',
      description: 'Technical diagnostics report including component health checks, system integrity tests, and predictive maintenance recommendations.',
      icon: <Cpu className="h-5 w-5 text-purple-500 mr-2" />,
      fileSize: '6.1 MB',
      fileType: 'excel',
      fileName: 'system-diagnostics-2025-q1.xlsx',
      sourceUrl: 'https://www.nrc.gov/docs/simulation/reports/system-diagnostics-2025-q1.html',
      showSourceLink: false
    }
  ];

  // Generate a simulated NRC document URL that points to a PDF
  const getNrcDocumentUrl = (sourceId: string) => {
    if (!sourceId || sourceId === 'Pending') {
      return undefined;
    }
    
    // Format: https://www.nrc.gov/cdn/doc-collection-news/2024/24-020-i.pdf
    const match = sourceId.match(/(\d{2})-(\d{3})/);
    if (match) {
      const year = match[1] === '24' ? '2024' : '2025';
      return `https://www.nrc.gov/cdn/doc-collection-news/${year}/${sourceId}.pdf`;
    }
    
    return undefined;
  };

  // Function to export data to Excel
  const exportToExcel = () => {
    let dataToExport: any[] = [];
    let filename = 'reactor-report';
    
    if (selectedReport === 'performance') {
      dataToExport = performanceData;
      filename = 'reactor-performance-report';
    } else if (selectedReport === 'safety') {
      dataToExport = safetyData;
      filename = 'reactor-safety-report';
    } else if (selectedReport === 'maintenance') {
      dataToExport = maintenanceData;
      filename = 'reactor-maintenance-report';
    }
    
    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Report Data");
    
    // Generate Excel file
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    // Save file
    saveAs(blob, `${filename}-${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
  };

  // Function to export data to PDF
  const exportToPDF = () => {
    setIsExporting(true);
    
    // Simulate PDF generation with a timeout
    setTimeout(() => {
      // Create dummy blob to simulate PDF data
      const pdfBlob = new Blob(['PDF content would go here in a real implementation'], 
        { type: 'application/pdf' });
      
      // Determine filename based on selected report
      let filename = 'reactor-report';
      if (selectedReport === 'performance') {
        filename = 'reactor-performance-report';
      } else if (selectedReport === 'safety') {
        filename = 'reactor-safety-report';
      } else if (selectedReport === 'maintenance') {
        filename = 'reactor-maintenance-report';
      }
      
      // Save the file
      saveAs(pdfBlob, `${filename}-${format(new Date(), 'yyyy-MM-dd')}.pdf`);
      setIsExporting(false);
    }, 1000);
  };

  // Function to download archive reports
  const downloadArchiveReport = (report: ArchiveReport) => {
    // Create dummy blob based on file type
    const content = `This is simulated content for ${report.title}`;
    let blob;
    
    if (report.fileType === 'excel') {
      // For Excel, create a simple spreadsheet
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet([
        ['Simulated Data for', report.title],
        ['Date', format(new Date(), 'yyyy-MM-dd')],
        ['Description', report.description]
      ]);
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    } else {
      // For PDF, create a text blob (in real app would be actual PDF content)
      blob = new Blob([content], { type: 'application/pdf' });
    }
    
    // Save the file
    saveAs(blob, report.fileName);
  };
  
  // Get period name from ID for display
  const getPeriodName = (periodId: string) => {
    const period = reportPeriods.find(p => p.id === periodId);
    return period ? period.name : 'Unknown Period';
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Reactor Reports</h1>
        <p className="text-gray-500 dark:text-gray-400">
          View and download detailed reports on reactor performance and operations
        </p>
      </div>

      {appMode === 'kids' && (
        <div className="bg-blue-100 dark:bg-blue-900/30 rounded-lg p-4 mb-6 border-2 border-blue-200 dark:border-blue-800">
          <h3 className="font-bold text-blue-800 dark:text-blue-200 text-lg">Learning Corner!</h3>
          <p className="text-blue-700 dark:text-blue-300 mt-1">
            Reports help engineers keep track of how the reactor is performing. They can download these 
            reports to share with their team and make improvements to the reactor's operation.
          </p>
        </div>
      )}
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
          <div className="flex-1">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
              {selectedReport === 'performance' && 'Performance Report'}
              {selectedReport === 'safety' && 'Safety Compliance Report'}
              {selectedReport === 'maintenance' && 'Maintenance Schedule Report'}
            </h2>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                selectedReport === 'performance' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setSelectedReport('performance')}
            >
              Performance
            </button>
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                selectedReport === 'safety' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setSelectedReport('safety')}
            >
              Safety
            </button>
            <button
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                selectedReport === 'maintenance' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}
              onClick={() => setSelectedReport('maintenance')}
            >
              Maintenance
            </button>
          </div>
        </div>
        
        {selectedReport !== 'maintenance' && (
          <div className="mb-4 flex flex-wrap gap-2">
            {reportPeriods.map((period) => (
              <button
                key={period.id}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  selectedPeriod === period.id
                  ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                  : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
                }`}
                onClick={() => setSelectedPeriod(period.id)}
              >
                {period.name}
              </button>
            ))}
          </div>
        )}
        
        <div className="h-80 mb-4">
          {selectedReport === 'performance' && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={performanceData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
                <XAxis dataKey="date" tick={{ fill: '#9CA3AF' }} />
                <YAxis tick={{ fill: '#9CA3AF' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(17, 24, 39, 0.8)',
                    border: 'none',
                    borderRadius: '4px',
                    color: '#F9FAFB'
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="efficiency" name="Efficiency %" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="output" name="Power Output (MW)" stroke="#3B82F6" strokeWidth={2} />
                <Line type="monotone" dataKey="temperature" name="Core Temp (°C)" stroke="#EF4444" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          )}
          
          {selectedReport === 'safety' && (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={safetyData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
                <XAxis dataKey="date" tick={{ fill: '#9CA3AF' }} />
                <YAxis tick={{ fill: '#9CA3AF' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(17, 24, 39, 0.8)',
                    border: 'none',
                    borderRadius: '4px',
                    color: '#F9FAFB'
                  }}
                />
                <Legend />
                <Bar dataKey="warnings" name="Safety Warnings" fill="#F59E0B" />
                <Bar dataKey="incidents" name="Safety Incidents" fill="#EF4444" />
                <Bar dataKey="tests" name="Safety Tests Completed" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          )}
          
          {selectedReport === 'maintenance' && (
            <div className="overflow-auto max-h-80">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-900">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Component
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Last Maintenance
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Next Due
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      NRC Document Number
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {maintenanceData.map((item, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        {item.component}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {item.lastMaintenance}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {item.nextDue}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          item.status === 'Good' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                          item.status === 'Due' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100' :
                          'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <a 
                          href={getNrcDocumentUrl(item.nrcRef.split('-')[2])}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center text-blue-600 dark:text-blue-400 hover:underline"
                        >
                          {item.nrcRef}
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Report Details</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Generated on {format(new Date(), 'MMMM d, yyyy')} • System Mode: {systemMode} • Period: {getPeriodName(selectedPeriod)}
              </p>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={exportToExcel}
                className="flex items-center px-3 py-2 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700 transition-colors"
              >
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Export Excel
              </button>
              <button
                onClick={exportToPDF}
                disabled={isExporting}
                className={`flex items-center px-3 py-2 ${
                  isExporting 
                    ? 'bg-blue-400 cursor-not-allowed' 
                    : 'bg-blue-600 hover:bg-blue-700'
                } text-white rounded-md text-sm font-medium transition-colors`}
              >
                <FileText className="h-4 w-4 mr-2" />
                {isExporting ? 'Exporting...' : 'Export PDF'}
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 mb-6">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Report Archives</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {archiveReports.map(report => (
            <div key={report.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
              <div className="flex items-center mb-3">
                {report.icon}
                <h3 className="font-medium text-gray-900 dark:text-white">{report.title}</h3>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                {report.description}
              </p>
              <div className="flex justify-between">
                <button 
                  className="flex items-center text-sm text-blue-600 dark:text-blue-400 hover:underline"
                  onClick={() => downloadArchiveReport(report)}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download ({report.fileSize})
                </button>
                {report.showSourceLink && (
                  <a 
                    href={report.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-sm text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    View Source <ExternalLink className="ml-1 h-3 w-3" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="text-sm text-gray-500 dark:text-gray-400 italic">
        Data in this module is simulated for educational purposes only. Real reactor operations require comprehensive engineering validation under regulatory oversight.
      </div>
    </div>
  );
};

export default Reports;
