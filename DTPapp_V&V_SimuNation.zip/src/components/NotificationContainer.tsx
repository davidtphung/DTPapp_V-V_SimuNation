import React, { useState, useEffect } from 'react';
import { useNotifications, Notification } from '../context/NotificationContext';
import { X } from 'lucide-react';

const NotificationContainer: React.FC = () => {
  const { notifications, removeNotification } = useNotifications();
  const [visibleNotifications, setVisibleNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    // Add new unread notifications to visible list
    const newUnread = notifications.filter(
      n => !n.read && !visibleNotifications.some(vn => vn.id === n.id)
    );
    
    if (newUnread.length > 0) {
      setVisibleNotifications(prev => [...newUnread, ...prev]);
    }
  }, [notifications]);

  const handleDismiss = (id: string) => {
    setVisibleNotifications(prev => prev.filter(n => n.id !== id));
    // Don't remove from actual notifications, just mark as read
    // removeNotification(id);
  };

  // Auto-dismiss notifications after 5 seconds
  useEffect(() => {
    const timers: NodeJS.Timeout[] = [];
    
    visibleNotifications.forEach(notification => {
      const timer = setTimeout(() => {
        handleDismiss(notification.id);
      }, 5000);
      timers.push(timer);
    });
    
    return () => {
      timers.forEach(timer => clearTimeout(timer));
    };
  }, [visibleNotifications]);

  if (visibleNotifications.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-16 right-4 z-50 w-80 max-w-full space-y-2">
      {visibleNotifications.map(notification => (
        <div 
          key={notification.id}
          className={`${
            notification.type === 'info' ? 'bg-blue-50 border-blue-300 dark:bg-blue-900/70 dark:border-blue-700' :
            notification.type === 'warning' ? 'bg-yellow-50 border-yellow-300 dark:bg-yellow-900/70 dark:border-yellow-700' :
            notification.type === 'error' ? 'bg-red-50 border-red-300 dark:bg-red-900/70 dark:border-red-700' :
            'bg-green-50 border-green-300 dark:bg-green-900/70 dark:border-green-700'
          } border rounded-lg shadow-lg p-4 transform transition-all duration-300 ease-in-out animate-slideIn`}
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className={`text-sm font-medium ${
                notification.type === 'info' ? 'text-blue-800 dark:text-blue-200' :
                notification.type === 'warning' ? 'text-yellow-800 dark:text-yellow-200' :
                notification.type === 'error' ? 'text-red-800 dark:text-red-200' :
                'text-green-800 dark:text-green-200'
              }`}>
                {notification.type.charAt(0).toUpperCase() + notification.type.slice(1)}
              </h3>
              <p className="mt-1 text-sm text-gray-700 dark:text-gray-300">{notification.message}</p>
            </div>
            <button 
              onClick={() => handleDismiss(notification.id)}
              className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400 focus:outline-none"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default NotificationContainer;
