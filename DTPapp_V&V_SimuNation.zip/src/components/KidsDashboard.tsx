import React from 'react';
import { useReactorData } from '../context/ReactorDataContext';
import { ArrowDown, ArrowUp, Droplets, Gauge, Thermometer, Zap } from 'lucide-react';
import KidsModeAlert from './KidsModeAlert';

const KidsDashboard: React.FC = () => {
  const { reactorData, systemMode, updateControlRods } = useReactorData();

  // Simplified explanations for kids
  const getTemperatureExplanation = () => {
    if (reactorData.coreTemperature < 300) return "The reactor is cool right now.";
    if (reactorData.coreTemperature < 450) return "This is a good temperature for the reactor.";
    return "The reactor is getting hot! We might need to cool it down.";
  };

  const getPowerExplanation = () => {
    if (reactorData.powerOutput < 30) return "The reactor is making just a little bit of electricity.";
    if (reactorData.powerOutput < 80) return "The reactor is making enough electricity for thousands of homes!";
    return "The reactor is making a LOT of electricity! That's enough for a whole city!";
  };

  const handleRodChange = (position: number) => {
    updateControlRods(position);
  };

  return (
    <div>
      <KidsModeAlert />
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg border-2 border-indigo-200 dark:border-indigo-700 p-5 mb-6">
        <h2 className="text-xl font-bold text-indigo-700 dark:text-indigo-300 mb-4">Reactor Learning Dashboard</h2>
        
        <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-4 mb-6">
          <p className="text-indigo-700 dark:text-indigo-300">
            Welcome to the nuclear reactor simulator! This is a safe place to learn how nuclear reactors work. 
            Nuclear reactors make electricity by splitting atoms, which creates heat to make steam that spins turbines.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 rounded-lg p-4 border border-red-200 dark:border-red-800">
            <div className="flex items-center mb-2">
              <Thermometer className="h-8 w-8 text-red-500 mr-2" />
              <h3 className="text-lg font-medium text-red-700 dark:text-red-300">Reactor Temperature</h3>
            </div>
            <div className="text-3xl font-bold text-red-800 dark:text-red-200 mb-2">
              {reactorData.coreTemperature.toFixed(0)}°C
            </div>
            <p className="text-sm text-red-600 dark:text-red-400">
              {getTemperatureExplanation()}
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
            <div className="flex items-center mb-2">
              <Droplets className="h-8 w-8 text-blue-500 mr-2" />
              <h3 className="text-lg font-medium text-blue-700 dark:text-blue-300">Cooling Water</h3>
            </div>
            <div className="text-3xl font-bold text-blue-800 dark:text-blue-200 mb-2">
              {reactorData.coolantFlow.toFixed(0)} m³/h
            </div>
            <p className="text-sm text-blue-600 dark:text-blue-400">
              Water keeps the reactor cool and safe.
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
            <div className="flex items-center mb-2">
              <Gauge className="h-8 w-8 text-green-500 mr-2" />
              <h3 className="text-lg font-medium text-green-700 dark:text-green-300">Electricity Made</h3>
            </div>
            <div className="text-3xl font-bold text-green-800 dark:text-green-200 mb-2">
              {reactorData.powerOutput.toFixed(0)} MW
            </div>
            <p className="text-sm text-green-600 dark:text-green-400">
              {getPowerExplanation()}
            </p>
          </div>
        </div>
        
        <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4 mb-6 border border-yellow-200 dark:border-yellow-800">
          <div className="flex items-center mb-3">
            <Zap className="h-6 w-6 text-yellow-500 mr-2" />
            <h3 className="text-lg font-medium text-yellow-700 dark:text-yellow-300">Control Rods</h3>
          </div>
          
          <p className="text-sm text-yellow-600 dark:text-yellow-400 mb-4">
            Control rods help us control how much energy the reactor makes. Move the slider to see what happens!
          </p>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => handleRodChange(Math.max(0, reactorData.controlRodPosition - 10))}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-full p-2"
              disabled={systemMode === 'shutdown'}
            >
              <ArrowDown className="h-5 w-5" />
            </button>
            
            <div className="flex-1">
              <input
                type="range"
                min="0"
                max="100"
                value={reactorData.controlRodPosition}
                onChange={(e) => handleRodChange(Number(e.target.value))}
                disabled={systemMode === 'shutdown'}
                className="w-full"
                style={{
                  background: `linear-gradient(to right, 
                    #10B981 0%, 
                    #FBBF24 50%, 
                    #EF4444 100%)`
                }}
              />
              <div className="flex justify-between mt-1 text-xs text-yellow-600 dark:text-yellow-400">
                <span>Rods In (Less Energy)</span>
                <span>Rods Out (More Energy)</span>
              </div>
            </div>
            
            <button 
              onClick={() => handleRodChange(Math.min(100, reactorData.controlRodPosition + 10))}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-full p-2"
              disabled={systemMode === 'shutdown'}
            >
              <ArrowUp className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 border border-purple-200 dark:border-purple-800">
          <h3 className="text-lg font-medium text-purple-700 dark:text-purple-300 mb-2">Fun Reactor Facts</h3>
          <ul className="list-disc list-inside space-y-2 text-sm text-purple-600 dark:text-purple-400">
            <li>One uranium fuel pellet (about the size of a pencil eraser) contains as much energy as 17,000 cubic feet of natural gas!</li>
            <li>Nuclear reactors don't release carbon dioxide, which helps keep our air clean.</li>
            <li>Nuclear power plants can make electricity 24 hours a day, 7 days a week.</li>
            <li>There are about 440 nuclear reactors operating in more than 30 countries around the world.</li>
          </ul>
        </div>
      </div>
      
      <div className="text-center text-sm text-indigo-500 dark:text-indigo-400 italic">
        This is a simulation for educational purposes only. Real nuclear reactors have many more safety systems!
      </div>
    </div>
  );
};

export default KidsDashboard;
