import React from 'react';
import { useReactorData } from '../context/ReactorDataContext';
import { ExternalLink } from 'lucide-react';

const ControlRodSlider: React.FC = () => {
  const { reactorData, updateControlRods, systemMode } = useReactorData();
  
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateControlRods(Number(e.target.value));
  };

  // Calculate colors for visual representation
  const getColorForPosition = () => {
    const position = reactorData.controlRodPosition;
    if (position < 30) return 'bg-green-500';
    if (position < 70) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="flex flex-col">
      <div className="flex justify-between mb-2">
        <span className="text-sm text-gray-700 dark:text-gray-300">Fully Inserted (0%)</span>
        <span className="text-sm font-medium text-gray-900 dark:text-white">
          Current: {reactorData.controlRodPosition}%
        </span>
        <span className="text-sm text-gray-700 dark:text-gray-300">Fully Withdrawn (100%)</span>
      </div>
      
      <div className="relative w-full">
        <input
          type="range"
          min="0"
          max="100"
          value={reactorData.controlRodPosition}
          onChange={handleSliderChange}
          disabled={systemMode === 'shutdown'}
          className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
            systemMode === 'shutdown' ? 'bg-gray-300 dark:bg-gray-700' : 'bg-gray-200 dark:bg-gray-700'
          }`}
          style={{
            background: `linear-gradient(to right, 
              #10B981 0%, 
              #FBBF24 50%, 
              #EF4444 100%)`
          }}
        />
      </div>
      
      <div className="flex flex-col sm:flex-row justify-between mt-4 gap-2">
        <div className="rounded-md bg-gray-100 dark:bg-gray-800 p-2 border border-gray-200 dark:border-gray-700">
          <div className="text-xs font-medium text-gray-700 dark:text-gray-300">System Impact</div>
          <div className="text-sm mt-1 text-gray-900 dark:text-white">
            {reactorData.controlRodPosition < 30 && "Low power output - containment secure"}
            {reactorData.controlRodPosition >= 30 && reactorData.controlRodPosition < 70 && "Moderate power - normal operation range"}
            {reactorData.controlRodPosition >= 70 && "High power output - increased heat generation"}
          </div>
        </div>
        
        <div className="rounded-md bg-gray-100 dark:bg-gray-800 p-2 border border-gray-200 dark:border-gray-700">
          <div className="text-xs font-medium text-gray-700 dark:text-gray-300">NRC Guidance</div>
          <div className="text-sm mt-1 text-gray-900 dark:text-white">
            {reactorData.controlRodPosition < 30 && "Within conservative operational parameters"}
            {reactorData.controlRodPosition >= 30 && reactorData.controlRodPosition < 70 && (
              <span>
                Standard operational range per{' '}
                <a 
                  href="https://www.nrc.gov/cdn/doc-collection-news/2025/25-007.pdf" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center"
                >
                  25-007
                  <ExternalLink className="ml-1 h-3 w-3" />
                </a>
              </span>
            )}
            {reactorData.controlRodPosition >= 70 && "Extended range operation requires additional monitoring"}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ControlRodSlider;
