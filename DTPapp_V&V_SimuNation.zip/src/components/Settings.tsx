import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useAppMode } from '../context/AppModeContext';
import { useReactorData } from '../context/ReactorDataContext';
import { useNotifications } from '../context/NotificationContext';
import { ArrowRight, Brain, Moon, RefreshCw, Save, School, Sun, Trash2 } from 'lucide-react';

const Settings: React.FC = () => {
  const { darkMode, toggleDarkMode } = useTheme();
  const { appMode, setAppMode } = useAppMode();
  const { addNotification } = useNotifications();
  
  // Settings state
  const [refreshRate, setRefreshRate] = useState<number>(1500);
  const [alertThreshold, setAlertThreshold] = useState<number>(70);
  const [telemetryPoints, setTelemetryPoints] = useState<number>(10);
  const [showAlerts, setShowAlerts] = useState<boolean>(true);
  const [soundEffects, setSoundEffects] = useState<boolean>(false);
  
  // Save settings
  const saveSettings = () => {
    // In a real app, this would save to localStorage or backend
    addNotification("Settings saved successfully", "success");
  };
  
  // Reset settings to defaults
  const resetSettings = () => {
    setRefreshRate(1500);
    setAlertThreshold(70);
    setTelemetryPoints(10);
    setShowAlerts(true);
    setSoundEffects(false);
    addNotification("Settings reset to defaults", "info");
  };
  
  // Toggle sound effects
  const toggleSoundEffects = () => {
    setSoundEffects(!soundEffects);
    addNotification(`Sound effects ${!soundEffects ? 'enabled' : 'disabled'}`, "info");
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Settings</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Configure your simulation experience and interface preferences
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Interface Settings */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Interface Settings</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Application Mode</h3>
              <div className="flex flex-col space-y-2">
                <button
                  onClick={() => setAppMode('expert')}
                  className={`flex items-center justify-between px-4 py-3 border rounded-md ${
                    appMode === 'expert'
                      ? 'bg-blue-50 border-blue-300 dark:bg-blue-900/30 dark:border-blue-700'
                      : 'bg-white border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                  }`}
                >
                  <div className="flex items-center">
                    <Brain className={`h-5 w-5 ${appMode === 'expert' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400'} mr-3`} />
                    <div>
                      <p className={`font-medium ${appMode === 'expert' ? 'text-blue-700 dark:text-blue-300' : 'text-gray-700 dark:text-gray-300'}`}>
                        Expert Mode
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Full technical details and advanced controls
                      </p>
                    </div>
                  </div>
                  {appMode === 'expert' && (
                    <ArrowRight className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  )}
                </button>
                
                <button
                  onClick={() => setAppMode('kids')}
                  className={`flex items-center justify-between px-4 py-3 border rounded-md ${
                    appMode === 'kids'
                      ? 'bg-green-50 border-green-300 dark:bg-green-900/30 dark:border-green-700'
                      : 'bg-white border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                  }`}
                >
                  <div className="flex items-center">
                    <School className={`h-5 w-5 ${appMode === 'kids' ? 'text-green-600 dark:text-green-400' : 'text-gray-500 dark:text-gray-400'} mr-3`} />
                    <div>
                      <p className={`font-medium ${appMode === 'kids' ? 'text-green-700 dark:text-green-300' : 'text-gray-700 dark:text-gray-300'}`}>
                        Kids Learning Mode
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Simplified interface with educational explanations
                      </p>
                    </div>
                  </div>
                  {appMode === 'kids' && (
                    <ArrowRight className="h-5 w-5 text-green-600 dark:text-green-400" />
                  )}
                </button>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Theme</h3>
              <div className="flex space-x-4">
                <button
                  onClick={() => !darkMode && toggleDarkMode()}
                  className={`flex-1 flex flex-col items-center justify-center p-4 border rounded-md ${
                    darkMode
                      ? 'bg-gray-800 border-gray-600'
                      : 'bg-white border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                  }`}
                >
                  <Moon className={`h-6 w-6 mb-2 ${darkMode ? 'text-blue-400' : 'text-gray-400'}`} />
                  <span className={`text-sm font-medium ${darkMode ? 'text-white' : 'text-gray-500 dark:text-gray-400'}`}>Dark</span>
                </button>
                
                <button
                  onClick={() => darkMode && toggleDarkMode()}
                  className={`flex-1 flex flex-col items-center justify-center p-4 border rounded-md ${
                    !darkMode
                      ? 'bg-blue-50 border-blue-300 dark:bg-blue-900/30 dark:border-blue-700'
                      : 'bg-white border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                  }`}
                >
                  <Sun className={`h-6 w-6 mb-2 ${!darkMode ? 'text-amber-500' : 'text-gray-400 dark:text-gray-500'}`} />
                  <span className={`text-sm font-medium ${!darkMode ? 'text-gray-800' : 'text-gray-500 dark:text-gray-400'}`}>Light</span>
                </button>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Notifications</h3>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Show Alert Notifications</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={showAlerts}
                    onChange={() => setShowAlerts(!showAlerts)}
                    className="sr-only peer" 
                  />
                  <div className="w-11 h-6 bg-gray-200 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Sound Effects</h3>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Enable Sound Effects</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={soundEffects}
                    onChange={toggleSoundEffects}
                    className="sr-only peer" 
                  />
                  <div className="w-11 h-6 bg-gray-200 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          </div>
        </div>
        
        {/* Simulation Settings */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Simulation Settings</h2>
          
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Data Refresh Rate</h3>
                <span className="text-xs text-gray-500 dark:text-gray-400">{refreshRate}ms</span>
              </div>
              <input
                type="range"
                min="500"
                max="5000"
                step="100"
                value={refreshRate}
                onChange={(e) => setRefreshRate(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>Faster (500ms)</span>
                <span>Slower (5000ms)</span>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Warning Alert Threshold</h3>
                <span className="text-xs text-gray-500 dark:text-gray-400">{alertThreshold}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="90"
                step="5"
                value={alertThreshold}
                onChange={(e) => setAlertThreshold(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>More Sensitive (50%)</span>
                <span>Less Sensitive (90%)</span>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Telemetry Data Points</h3>
                <span className="text-xs text-gray-500 dark:text-gray-400">{telemetryPoints} points</span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="5"
                value={telemetryPoints}
                onChange={(e) => setTelemetryPoints(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>Fewer (5)</span>
                <span>More (30)</span>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex flex-col xs:flex-row xs:justify-between xs:items-center gap-3">
                <div className="text-sm text-gray-600 dark:text-gray-400 flex items-center">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Last updated: Just now
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={resetSettings}
                    className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Reset
                  </button>
                  <button
                    onClick={saveSettings}
                    className="px-3 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 flex items-center"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-8 text-sm text-gray-500 dark:text-gray-400 italic">
        Settings are saved to your local browser storage. Clearing browser data will reset all settings to defaults.
      </div>
    </div>
  );
};

export default Settings;
